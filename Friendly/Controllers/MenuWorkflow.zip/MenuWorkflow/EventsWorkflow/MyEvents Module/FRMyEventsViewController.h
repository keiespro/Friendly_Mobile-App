//
//  FRMyEventsViewController.h
//  Friendly
//
//  Created by Zaslavskaya Yevheniya on 17.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRBaseVC.h"

@interface FRMyEventsViewController : FRBaseVC

@property (nonatomic, assign) BOOL willShowEventPreview;
@end
