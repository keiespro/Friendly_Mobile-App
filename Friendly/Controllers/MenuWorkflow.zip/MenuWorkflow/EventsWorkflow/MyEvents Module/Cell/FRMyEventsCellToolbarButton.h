//
//  FRMyEventsCellToolbarButton.h
//  Friendly
//
//  Created by Jane Doe on 3/18/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRMyEventsCellToolbarButton : UIButton

@property (strong, nonatomic) UIImageView* image;
@property (strong, nonatomic) UILabel* title;


@end
