//
//  FRMyEventsFooterEventView.m
//  Friendly
//
//  Created by Jane Doe on 3/18/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRMyEventsFooterEventView.h"

@interface FRMyEventsFooterEventView()

@end

@implementation FRMyEventsFooterEventView

-(instancetype) init
{
    self = [super init];
    if (self)
    {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}


@end
