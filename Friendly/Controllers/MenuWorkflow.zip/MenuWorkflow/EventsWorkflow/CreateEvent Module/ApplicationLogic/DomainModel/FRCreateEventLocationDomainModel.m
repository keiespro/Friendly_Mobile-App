//
//  FRCreateEventLocationDomainModel.m
//  Friendly
//
//  Created by Sergey Borichev on 17.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRCreateEventLocationDomainModel.h"

@implementation FRCreateEventLocationDomainModel

@end
