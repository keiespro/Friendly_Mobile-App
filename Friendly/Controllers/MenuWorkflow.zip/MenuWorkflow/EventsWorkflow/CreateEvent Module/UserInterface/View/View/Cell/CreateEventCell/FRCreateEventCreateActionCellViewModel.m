//
//  FRCreateEventCreateActionCellViewModel.m
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRCreateEventCreateActionCellViewModel.h"

@implementation FRCreateEventCreateActionCellViewModel

@end
