//
//  FRCreateEventInviteFriendsFacebookButton.h
//  Friendly
//
//  Created by Zaslavskaya Yevheniya on 22.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRCreateEventInviteFriendsFacebookButton : UIButton

@end
