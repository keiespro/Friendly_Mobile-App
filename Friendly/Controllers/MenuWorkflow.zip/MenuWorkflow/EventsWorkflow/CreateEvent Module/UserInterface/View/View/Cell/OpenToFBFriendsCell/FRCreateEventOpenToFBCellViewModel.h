//
//  FRCreateEventOpenToFBCellViewModel.h
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FRCreateEventOpenToFBCellViewModel : NSObject

@property (nonatomic, assign) BOOL isOpen;

@end
