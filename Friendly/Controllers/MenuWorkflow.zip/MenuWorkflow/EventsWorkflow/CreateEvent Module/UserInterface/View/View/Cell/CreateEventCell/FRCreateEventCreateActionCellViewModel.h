//
//  FRCreateEventCreateActionCellViewModel.h
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FRCreateEventCreateActionCellViewModel : NSObject

@property (nonatomic, assign) BOOL canCreate;

@end
