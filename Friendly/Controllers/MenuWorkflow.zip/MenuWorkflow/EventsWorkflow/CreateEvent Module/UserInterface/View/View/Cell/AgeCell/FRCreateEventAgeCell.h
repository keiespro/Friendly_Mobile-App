//
//  FRCreateEventAgeCell.h
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "BSBaseTableViewCell.h"
#import "FRCreateEventAgeCellViewModel.h"

@interface FRCreateEventAgeCell : BSBaseTableViewCell

@property (nonatomic, strong) UILabel* titleLabel;
@property (nonatomic, strong) UILabel* dataLabel;

@end
