//
//  FRCreateEventInformationCellViewModel.m
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRCreateEventInformationCellViewModel.h"

@implementation FRCreateEventInformationCellViewModel

@end
