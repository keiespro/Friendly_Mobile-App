//
//  FRCreateEventInviteFriendsSearchView.h
//  Friendly
//
//  Created by Jane Doe on 3/22/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRCreateEventInviteFriendsSearchView : UIView

@property (strong, nonatomic) UITextField* searchField;
@property (strong, nonatomic) UIButton* closeButton;

@end
