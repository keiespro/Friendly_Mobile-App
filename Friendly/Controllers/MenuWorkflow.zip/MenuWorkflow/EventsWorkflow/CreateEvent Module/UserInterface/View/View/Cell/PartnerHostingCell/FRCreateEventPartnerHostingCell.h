//
//  FRCreateEventPartnerHostingCell.h
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "BSBaseTableViewCell.h"
#import "FRCreateEventPartnerHostingCellViewModel.h"
#import "CMPopTipView.h"

@interface FRCreateEventPartnerHostingCell : BSBaseTableViewCell

@property (nonatomic, strong) CMPopTipView* searchHelperView;// название тупо скопировал

@end
