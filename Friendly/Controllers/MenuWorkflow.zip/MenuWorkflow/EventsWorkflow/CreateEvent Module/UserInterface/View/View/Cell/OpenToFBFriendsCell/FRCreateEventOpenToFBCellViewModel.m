//
//  FRCreateEventOpenToFBCellViewModel.m
//  Friendly
//
//  Created by Sergey Borichev on 09.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRCreateEventOpenToFBCellViewModel.h"

@implementation FRCreateEventOpenToFBCellViewModel

@end
