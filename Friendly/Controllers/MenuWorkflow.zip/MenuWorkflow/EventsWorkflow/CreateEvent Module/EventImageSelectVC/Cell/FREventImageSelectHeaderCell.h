//
//  FREventImageSelectHeaderCell.h
//  Friendly
//
//  Created by User on 08.08.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FREventImageSelectHeaderCell : UICollectionViewCell

@end
