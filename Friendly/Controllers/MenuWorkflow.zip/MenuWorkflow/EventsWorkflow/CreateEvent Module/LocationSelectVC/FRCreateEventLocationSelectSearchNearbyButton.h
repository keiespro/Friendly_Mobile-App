//
//  FRCreateEventLocationSelectSearchNearbyButton.h
//  Friendly
//
//  Created by Jane Doe on 3/30/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRCreateEventLocationSelectSearchNearbyButton : UIButton

@property (nonatomic, strong) UILabel* subtitleLabel;

@end
