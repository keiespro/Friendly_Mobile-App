//
//  FRInformationTitleTableViewCell.h
//  Friendly
//
//  Created by Zaslavskaya Yevheniya on 10.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FREventPreviewTitleInfoCell : UITableViewCell

-(void)updateTitleInfoCellWithAttendingStatus;

@end
