//
//  FREventPreviewAttendingSmallFlowLayout.h
//  Friendly
//
//  Created by Jane Doe on 3/14/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FREventPreviewAttendingSmallFlowLayout : UICollectionViewFlowLayout

@end
