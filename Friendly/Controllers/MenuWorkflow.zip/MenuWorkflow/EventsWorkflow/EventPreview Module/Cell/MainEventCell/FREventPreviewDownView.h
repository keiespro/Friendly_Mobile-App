//
//  DownView.h
//  Project
//
//  Created by Jane Doe on 2/29/16.
//  Copyright © 2016 Jane Doe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FREventPreviewAttendingPeopleView.h"

@interface FREventPreviewDownView : UIView

@property (strong, nonatomic) FREventPreviewAttendingPeopleView* attendingView;


@end
