//
//  FREventFilterDistanceCellViewModel.m
//  Friendly
//
//  Created by Sergey Borichev on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FREventFilterDistanceCellViewModel.h"

@implementation FREventFilterDistanceCellViewModel

@end
