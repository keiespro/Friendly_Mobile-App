//
//  FREventFilterAgeRangeCellViewModel.h
//  Friendly
//
//  Created by Sergey Borichev on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FREventFilterAgeRangeCellViewModel : NSObject

@property (nonatomic, assign) NSInteger minAge;
@property (nonatomic, assign) NSInteger maxAge;

@end
