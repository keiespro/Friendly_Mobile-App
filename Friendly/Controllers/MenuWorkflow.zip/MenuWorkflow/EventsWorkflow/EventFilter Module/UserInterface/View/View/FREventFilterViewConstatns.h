//
//  FREventFilterViewConstatns.h
//  Friendly
//
//  Created by D on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

typedef NS_ENUM(NSInteger, FREventFilterCellType) {
    FREventFilterCellSortBy,
    FREventFilterCellWhatYouSee,
    FREventFilterCellDate,
    FREventFilterCellLocation,
    FREventFilterCellDistance,
    FREventFilterCellGender,
    FREventFilterCellAgeRange,
};