//
//  FREventFilterContentView.h
//  Friendly
//
//  Created by Sergey Borichev on 21.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FREventFilterContentView : UIView

@property (nonatomic, strong) UITableView* tableView;
@property (nonatomic, strong) UIButton* closeButton;
@property (nonatomic, strong) UIButton* doneButton;

@end
