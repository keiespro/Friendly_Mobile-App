//
//  FREventFilterAgeRangeCell.h
//  Friendly
//
//  Created by Sergey Borichev on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FREventFilterSliderCell.h"
#import "FREventFilterAgeRangeCellViewModel.h"

@interface FREventFilterAgeRangeCell : FREventFilterSliderCell


@end
