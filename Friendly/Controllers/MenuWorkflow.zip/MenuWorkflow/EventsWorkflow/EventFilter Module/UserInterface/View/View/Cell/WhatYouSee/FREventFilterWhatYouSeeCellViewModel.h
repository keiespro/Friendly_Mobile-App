//
//  FREventFilterWhatYouSeeCellViewModel.h
//  Friendly
//
//  Created by D on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FREventFilterWhatYouSeeCellViewModel : NSObject

@end
