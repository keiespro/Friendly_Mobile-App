//
//  FREventFilterAgeRangeCellViewModel.m
//  Friendly
//
//  Created by Sergey Borichev on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FREventFilterAgeRangeCellViewModel.h"

@implementation FREventFilterAgeRangeCellViewModel

@end
