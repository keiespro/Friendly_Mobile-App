//
//  FREventFilterDataCell.h
//  Friendly
//
//  Created by Sergey Borichev on 25.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRCreateEventAgeCell.h"

@interface FREventFilterDataCell : FRCreateEventAgeCell

@end
