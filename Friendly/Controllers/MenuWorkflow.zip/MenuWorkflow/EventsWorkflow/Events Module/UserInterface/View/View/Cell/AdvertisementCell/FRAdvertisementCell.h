//
//  FRAdvertisementCell.h
//  Friendly
//
//  Created by Sergey Borichev on 29.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "BSBaseTableViewCell.h"
#import "FRAdvertisementCellViewModel.h"

@interface FRAdvertisementCell : BSBaseTableViewCell

@end
