//
//  FRFriendsCellViewModel.m
//  Friendly
//
//  Created by Jane Doe on 4/28/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRFriendsCellViewModel.h"

@implementation FRFriendsCellViewModel

@end
