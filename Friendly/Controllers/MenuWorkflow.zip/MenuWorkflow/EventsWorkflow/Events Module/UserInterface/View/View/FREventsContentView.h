//
//  FREventsContentView.h
//  Friendly
//
//  Created by Sergey Borichev on 11.04.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FREventsContentView : UIView

@end
