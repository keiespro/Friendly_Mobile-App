//
//  FRInviteToEventViewController.h
//  Friendly
//
//  Created by User on 29.06.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "WhiteHeaderVC.h"

@interface FRInviteToEventViewController : WhiteHeaderVC

@property (strong, nonatomic) NSString* userId;

@end
