//
//  FREventRequestsInviteHeader.h
//  Friendly
//
//  Created by Jane Doe on 4/4/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FREventRequestsInviteHeader : UITableViewHeaderFooterView

@property (nonatomic, strong) UILabel* titleLabel;

@end
