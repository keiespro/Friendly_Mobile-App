//
//  FREventRequestsInviteModel.m
//  Friendly
//
//  Created by Jane Doe on 4/7/16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FREventRequestsInviteModel.h"

@implementation FREventRequestsInviteModel

@end
