//
//  FRPrivateChatUserHeader.h
//  Friendly
//
//  Created by Dmitry on 11.06.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRPrivateChatUserHeaderViewModel.h"

@interface FRPrivateChatUserHeader : UICollectionReusableView

- (void)updateWithModel:(FRPrivateChatUserHeaderViewModel*)model;

@end
