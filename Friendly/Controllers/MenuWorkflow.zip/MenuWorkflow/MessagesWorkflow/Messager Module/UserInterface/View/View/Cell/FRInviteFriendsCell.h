//
//  FRInviteFriendsCell.h
//  Friendly
//
//  Created by Sergey Borichev on 19.05.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "BSBaseTableViewCell.h"
#import "FRInviteFriendsCellViewModel.h"

@interface FRInviteFriendsCell : BSBaseTableViewCell

@end
