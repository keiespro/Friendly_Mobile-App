//
//  FRMessagesGroupRoomCell.h
//  Friendly
//
//  Created by Sergey on 04.06.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "BSBaseTableViewCell.h"
#import "FRMessagesGroupRoomCellViewModel.h"

@interface FRMessagesGroupRoomCell : BSBaseTableViewCell

@end
