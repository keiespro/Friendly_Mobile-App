//
//  FRMessagerSectionHeader.h
//  Friendly
//
//  Created by Dmitry on 17.07.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//


@interface FRMessagerSectionHeader : UITableViewHeaderFooterView

@end
