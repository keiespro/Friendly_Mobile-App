//
//  FRMessagerChatPreviewVC.h
//  Friendly
//
//  Created by Sergey on 26.09.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRMessagerChatPreviewVC : UIViewController

@end
