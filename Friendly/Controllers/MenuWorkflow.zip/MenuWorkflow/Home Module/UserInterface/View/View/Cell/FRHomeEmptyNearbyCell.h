//
//  FRHomeEmptyNearbyCell.h
//  Friendly
//
//  Created by Dmitry on 21.07.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRHomeEmptyNearbyCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *addFriends;

@end
