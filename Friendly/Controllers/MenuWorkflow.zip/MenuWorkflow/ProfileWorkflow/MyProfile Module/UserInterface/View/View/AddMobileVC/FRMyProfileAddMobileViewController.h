//
//  FRMyProfileAddMobileViewController.h
//  Friendly
//
//  Created by User on 23.09.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "WhiteHeaderVC.h"

@interface FRMyProfileAddMobileViewController : WhiteHeaderVC

@end
