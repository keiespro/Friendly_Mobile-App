//
//  FRFriendsEventsSectionHeader.h
//  Friendly
//
//  Created by Sergey on 03.07.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FRInviteFriendsCellViewModel.h"

@interface FRFriendsEventsSectionHeader : UITableViewHeaderFooterView

- (void)updateWithModel:(id)model;

@end
