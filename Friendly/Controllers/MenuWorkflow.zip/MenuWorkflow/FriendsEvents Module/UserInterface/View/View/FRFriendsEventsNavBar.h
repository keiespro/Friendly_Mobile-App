//
//  FRFriendsEventsNavBar.h
//  Friendly
//
//  Created by Dmitry on 03.07.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRFriendsEventsNavBar : UIView

@property (nonatomic, strong) UILabel* titleLabel;
@property (nonatomic, strong) UIButton* leftButton;

@end
