//
//  FREventSubCollectionCell.h
//  Friendly
//
//  Created by Sergey Borichev on 16.03.16.
//  Copyright © 2016 TecSynt. All rights reserved.
//

#import "FREventCollectionCell.h"

@interface FREventSubCollectionCell : FREventCollectionCell

@end
